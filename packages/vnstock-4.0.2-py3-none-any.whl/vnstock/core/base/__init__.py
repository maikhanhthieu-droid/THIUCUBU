"""Base module initialization."""
